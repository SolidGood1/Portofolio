const emailRx = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phoneRx = /^\d{10,}$/;

// ── Simulated registered accounts (replace with real API check in prod) ──
const REGISTERED_ACCOUNTS = ['test@email.com', '08123456789', '081234567890'];

function isValidEmailOrPhone(val) {
    return emailRx.test(val) || phoneRx.test(val.replace(/[\s\-\(\)]/g, ''));
}

async function handleRegister() {
    const emailInput =
        document.getElementById('reg-email');

    const val =
        emailInput.value.trim();

    if (!isValidEmailOrPhone(val)) {
        return;
    }

    const response = await fetch(
        'http://localhost:3000/register',
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: val,
                phone: null,
                password: 'temporary',
                role: 'student'
            })
        }
    );

    const data = await response.json();

    if (data.success) {
        localStorage.setItem(
            'pendingUser',
            val
        );

        window.location.href =
            `verify.html?flow=register&dest=${encodeURIComponent(val)}`;
    }
}

function handleGoogleRegister() {
    // Simulate Google OAuth returning an email.
    // In production, replace this with your actual Google OAuth flow
    // and check the returned email against your user database.
    const googleEmail = 'google-user@gmail.com'; // placeholder from OAuth
    const isRegistered = REGISTERED_ACCOUNTS.includes(googleEmail.toLowerCase().trim());

    if (isRegistered) {
        // Account already exists → go straight to cariMentor (treat as login)
        window.location.href = '../cariMentor.html';
    } else {
        // New account → go to dataAkun to complete profile
        window.location.href = 'dataAkunStudent.html';
    }
}

document.getElementById('reg-email').addEventListener('keydown', e => { if (e.key === 'Enter') handleRegister(); });