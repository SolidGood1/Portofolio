async function loadUser() {

  const res = await fetch(
    'http://localhost:3000/me',
    {
      credentials: 'include'
    }
  );

  const data = await res.json();

  const navAction =
    document.getElementById('navAction');

  if (data.loggedIn) {

    navAction.innerHTML = `
      <a
        href="student/editProfile.html"
        class="btn-nav"
      >
        Akun
      </a>
    `;

  } else {

    navAction.innerHTML = `
      <a
        href="login.html"
        class="btn-nav"
      >
        Daftar/Masuk
      </a>
    `;
  }
}

document
  .getElementById('btnCariMentor')
  .addEventListener('click', async (e) => {

    e.preventDefault();

    const res = await fetch(
      'http://localhost:3000/me',
      {
        credentials: 'include'
      }
    );

    const data = await res.json();

    if (data.loggedIn) {
      window.location.href = 'cariMentor.html';
    } else {
      window.location.href = 'register.html';
    }

  });

loadUser();